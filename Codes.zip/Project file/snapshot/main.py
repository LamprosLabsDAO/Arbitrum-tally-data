import pandas as pd
import spacy

# Load spaCy model for text preprocessing and word vectors
nlp = spacy.load('en_core_web_md')

# Preprocess proposal names
def preprocess_text(text):
    doc = nlp(text.lower())  # Convert to lowercase and tokenize
    tokens = [token.text for token in doc if not token.is_punct and not token.is_stop]
    return ' '.join(tokens)

# Load datasets
dataset1 = pd.read_csv('snap_proposal_data.csv')
dataset2 = pd.read_csv('tally_proposal_data.csv')


# Preprocess proposal names in both datasets
dataset1['processed_name'] = dataset1['proposal_name'].apply(preprocess_text)
dataset2['processed_name'] = dataset2['proposal_name'].apply(preprocess_text)

# Function to calculate similarity between two proposal names using spaCy word vectors
def calculate_similarity(name1, name2):
    vec1 = nlp(name1).vector
    vec2 = nlp(name2).vector
    similarity = vec1.dot(vec2) / (vec1.norm() * vec2.norm())
    return similarity

# Mapping and merging proposals
mapped_proposals = []
for name1 in dataset1['processed_name']:
    for name2 in dataset2['processed_name']:
        similarity = calculate_similarity(name1, name2)
        if similarity > 0.8:  # Example similarity threshold
            mapped_proposals.append((name1, name2, similarity))

# Create DataFrame from mapped proposals
mapped_df = pd.DataFrame(mapped_proposals, columns=['proposal_name_dataset1', 'proposal_name_dataset2', 'similarity'])

# Merge datasets based on mapped proposal names
merged_dataset = pd.merge(mapped_df, dataset1, left_on='proposal_name_dataset1', right_on='processed_name', how='left')
merged_dataset = pd.merge(merged_dataset, dataset2, left_on='proposal_name_dataset2', right_on='processed_name', how='left')

# Drop unnecessary columns
merged_dataset.drop(['processed_name_x', 'processed_name_y'], axis=1, inplace=True)

# Save merged dataset to a new CSV file
merged_dataset.to_csv('merged_dataset.csv', index=False)
