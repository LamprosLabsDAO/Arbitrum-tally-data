import csv
from collections import defaultdict

def process_csv(csv_file):
    # Dictionary to store voter information
    voter_data = defaultdict(lambda: {'total_proposals': 0, 'total_votes': 0, 'total_for_votes': 0, 'total_against_votes': 0, 'total_abstain_votes' : 0,'total_weight': 0})

    try:
        with open(csv_file, 'r', encoding='utf-8') as file:
            csv_reader = csv.reader(file, delimiter=',')  # Assuming the CSV file is tab-delimited
            next(csv_reader)  # Skip header if exists

            for row in csv_reader:
                proposal_id, voter_id, _,_,_, vote, weight,_,_,_ = row


                # Convert weight to a float
                weight = float(weight)

                # Update voter information
                voter_data[voter_id]['total_proposals'] += 1
                voter_data[voter_id]['total_votes'] += 1
                voter_data[voter_id]['total_weight'] += weight

                if vote == 'FOR':
                    voter_data[voter_id]['total_for_votes'] += 1
                elif vote == 'AGAINST':
                    voter_data[voter_id]['total_against_votes'] += 1
                else :
                    voter_data[voter_id]['total_abstain_votes'] += 1
    except Exception as e:
        print(f"Error processing CSV file: {e}")
        return None

    return voter_data

def write_to_csv(output_csv_file, voter_data):
    try:
        with open(output_csv_file, 'w', newline='', encoding='utf-8') as csv_writer:
            csv_writer_object = csv.writer(csv_writer)

            # Write header
            csv_writer_object.writerow(['Voter ID', 'Total Proposals', 'Total Votes', 'Total FOR Votes', 'Total AGAINST Votes', 'Total Weight','Total ABSTAINED votes'])

            # Write data
            for voter_id, data in voter_data.items():
                csv_writer_object.writerow([voter_id, data['total_proposals'], data['total_votes'], data['total_for_votes'], data['total_against_votes'], data['total_weight'],data['total_abstain_votes']])

        print(f"Data successfully written to CSV file: {output_csv_file}")

    except Exception as e:
        print(f"Error writing to CSV file: {e}")

# Example usage:
csv_file_path = 'voters_data/voter_data2.csv'
output_csv_file_path = 'voters_data/unique_voters_data.csv'

voter_data = process_csv(csv_file_path)

if voter_data:
    write_to_csv(output_csv_file_path, voter_data)
