import requests
from datetime import datetime
import json
from data_juggler import *
# GraphQL endpoint URL
graphql_url = 'https://api.tally.xyz/query'

graphql_query= """query GovernanceProposals($sort: ProposalSort, $chainId: ChainID!, $pagination: Pagination, $governanceIds: [AccountID!], $proposerIds: [AccountID!]) {
  proposals(
    sort: $sort
    chainId: $chainId
    pagination: $pagination
    governanceIds: $governanceIds
    proposerIds: $proposerIds
  ) {
    id
    title
    
    voteStats {
      votes
      weight
      support
      percent
    }
    
    
    tallyProposal {
      id
      createdAt
      status
    }
  }
}

"""
variables = {
  "sort": {
        "field": "START_BLOCK",
        "order": "DESC"
    },
    "chainId": "eip155:42161",
    "pagination": {
        "limit": 15,
        "offset": 30
    },
    "governanceIds": ["eip155:42161:0xf07DeD9dC292157749B6Fd268E37DF6EA38395B9", "eip155:42161:0x789fC99093B09aD01C34DC7251D0C89ce743e5a4"],
    "votersPagination": {
        "limit": 1,
        "offset": 0
    },
    "includeVotes": False
}
headers = {
    "Api-key": "d38c4414051a92477770f9998aa9be4c2183ea815b6ace505ec5e29b856fc36b"
}


# proposals_data = response_data.get('data', {}).get('proposals', [])
    
#             if proposals_data:
#                 # Assuming 'id' is the key for the IDs in each proposal
#                 ids_list = [proposal.get('id') for proposal in proposals_data if proposal.get('id') is not None]
                
#                 # Creating a DataFrame with the extracted IDs
#                 df = pd.DataFrame({'ID': ids_list})

create_json_from_api(graphql_url,"proposal.json",graphql_query,variables,headers,True)
json_to_csv("proposal.json","proposal_data.csv")
