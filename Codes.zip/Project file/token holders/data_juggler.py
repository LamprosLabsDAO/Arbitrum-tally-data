import pandas as pd
import json
import os 
import requests
import json
import csv 
import os



def clear_csv(file_path):
    try:
        with open(file_path, 'w', newline='') as csv_file:
            csv_file.truncate()
        print(f"All data cleared from the CSV file '{file_path}'.")
    except Exception as e:
        print(f"Error: {e}")

def check_csv_existence(file_path):
    return os.path.exists(file_path) and os.path.isfile(file_path) and file_path.endswith('.csv')


def json_to_data(json_file):
    try:
        # Read JSON file into a DataFrame
        with open(json_file, 'r') as file:
            response_data = json.load(file)
            df = pd.json_normalize(response_data)
            return df
            # If the CSV file exists, append datxa without the header
    except Exception as e: 
        print(f"Error converting JSON to CSV: {str(e)}")
        
        
# flag true if want to mention required columns
def data_to_csv(df,csv_file):
    flag=False
    # change the field requirement and edit the fields here 
    
    data=df
        
    try:
        if check_csv_existence(csv_file):
            # If the CSV file does not exist, write the header
            data.to_csv(csv_file, mode='a', header=False, index=False)
            print(f"Data appended to existing CSV file: {csv_file}")
            
        else:
            data.to_csv(csv_file,header=True, index=False)
            print(f"CSV file successfully created: {csv_file}")
            # If the CSV file exists, append datxa without the header
            
    except Exception as e: 
        print(f"Error converting JSON to CSV: {str(e)}")
    return
            
            
        
def json_to_csv(json_file, csv_file):
    try:
        # Read JSON file into a DataFrame
        with open(json_file, 'r') as file:
            data = json.load(file)
        
        header = ['proposal_id', 'voter.address', 'voter.ens', 'voter.name', 'voter_type', 'support','weight','block_number','timestamp']
        mode = 'a' if check_csv_existence(csv_file) else 'w'
                    
        with open(csv_file, mode, newline='', encoding='utf-8') as csv_writer:
            csv_writer_object = csv.writer(csv_writer)
            
            if mode == 'w':
                csv_writer_object.writerow(header)

            for proposal in data.get("data", {}).get("proposals", []):
                proposal_id = proposal.get("id", "")
                # governance_id = proposal.get("governanceId", "")
                title = proposal.get("title", "")

                for vote in proposal.get("votes", []):
                    voter = vote.get("voter", {})
                    voter_id = voter.get("id", "")
                
                    voter_address = voter.get("address", "")
                    voter_ens = voter.get("ens", "")
                    voter_name = voter.get("name", "")
                    voter_type = voter.get("type", "")
                    support = vote.get("support", "")
                    weight = vote.get("weight", "")
                    
                    block=vote.get("block","")
                    block_number=block.get("number","")
                    block_timestamp=block.get("timestamp","")
                    block_number=block.get("number","")
                    # weight = '{:.20f}'.format(vote.get("weight"))

                    proposal_data = [
                        # governance_id,
                        proposal_id,
                        voter_address,
                        voter_ens,
                        voter_name,
                        voter_type,
                        support,
                        weight,
                        block_number,
                        block_timestamp
                    ]

                    csv_writer_object.writerow(proposal_data)

        if mode == 'a':
            print(f"Data appended to existing CSV file: {csv_file}")
        else:
            print(f"CSV file successfully created with headers: {csv_file}")

    except Exception as e:
        print(f"Error converting JSON to CSV: {e}")


        # if check_csv_existence(csv_file):
        #     # If the CSV file does not exist, write the header
        #     df.to_csv(csv_file, mode='a', header=False, index=False)
        #     print(f"Data appended to existing CSV file: {csv_file}")
            
        # else:
        #     df.to_csv(csv_file,header=True, index=False)
        #     print(f"CSV file successfully created: {csv_file}")
        #     # If the CSV file exists, append datxa without the header

    # except Exception as e: 
    #     print(f"Error converting JSON to CSV: {str(e)}")
        
# flag true if want to creat api json file 

def create_json_from_api(api_url, json_file,query,variable,header,flag):
    try:
    
        response = requests.post(api_url, json={'query': query, 'variables': variable}, headers=header)
        
        if response.status_code == 200:
            # Parse JSON data
            api_data = response.json()
            # Write JSON data to a file
            if flag:
                    with open(json_file, 'w') as json_file:
                        json.dump(api_data, json_file, indent=4)

                    print(f"JSON data successfully written to {json_file}")
                    
            
        else:
            print(f"API request failed with status code {response.status_code}")
            return False

    except Exception as e:
        print(f"Error querying API: {e}")   
        return False


# api_url = "https://forum.arbitrum.foundation/c/24/show.json"  # Replace with your API endpoint
# create_json_from_api(api_url,"",True)

def add_column_to_csv(csv_file, new_column_name, data_list):
    try:
        # Read existing CSV file into a DataFrame
        df = pd.read_csv(csv_file)

        # Add a new column with the given data
        df[new_column_name] = data_list

        # Write the updated DataFrame back to the CSV file
        df.to_csv(csv_file, index=False)

        print(f"Column '{new_column_name}' added to the CSV file '{csv_file}'.")
    except Exception as e:
        print(f"Error: {e}")