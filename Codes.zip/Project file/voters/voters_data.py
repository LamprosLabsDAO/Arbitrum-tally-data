import requests
from datetime import datetime
import json
from data_juggler import *
# GraphQL endpoint URL
graphql_url = 'https://api.tally.xyz/query'

graphql_query= """query GovernanceProposals($sort: ProposalSort, $chainId: ChainID!, $pagination: Pagination, $governanceIds: [AccountID!], $proposalIds: [ID!], $voters: [Address!], $votersPagination: Pagination, $includeVotes: Boolean!) {
  proposals(
    sort: $sort
    chainId: $chainId
    pagination: $pagination
    governanceIds: $governanceIds
    proposalIds: $proposalIds
  ) {
    governanceId
    id
    votes(voters: $voters, pagination: $votersPagination) @include(if: $includeVotes) {
  
      voter {
  			id
        address
        ens
        name
        type
        
      }
      support
      weight
      reason
      hash
      
      block {
        number
        timestamp
        ts
      }
    }
    
  }
}
"""
variables =  {
    "proposalIds": ["98889951328992702889653461987621825257851718470562453684547824130828387112157"],
    
  	"sort": {
        "field": "START_BLOCK",
        "order": "DESC"
    },
    "chainId": "eip155:42161",
 
    "governanceIds": ["eip155:42161:0xf07DeD9dC292157749B6Fd268E37DF6EA38395B9", "eip155:42161:0x789fC99093B09aD01C34DC7251D0C89ce743e5a4"],
    "votersPagination": {
        "limit": 10000,
        "offset": 0
    },
    "includeVotes": True
  
}
  

headers = {
    "Api-key": "d38c4414051a92477770f9998aa9be4c2183ea815b6ace505ec5e29b856fc36b"
}

input_data="proposal_data.csv"
output_data="voter_data2.csv"
# csv_data=csv.reader(input_data)
with open(input_data,'r',encoding='utf-8') as file:
  proposal_ids = csv.reader(file)
  proposal_id=next(proposal_ids)
  proposal_id_list = [row[0] for row in proposal_ids]
  print(len(proposal_id_list))
  # variables["proposalIds"]=proposal_id_list
  
  # for id in proposal_ids:
# for id in proposal_ids:
# json_to_csv("voters_data.json", "voter_data.csv")
# if create_json_from_api(graphql_url, "voters_data.json", graphql_query, variables, headers, True):
#               json_to_csv("voters_data.json", output_data)
for proposal_id in proposal_id_list:
  temp=0
  
  while True:
            variables["votersPagination"]['offset'] = temp
            variables['proposalIds']=[proposal_id]
            if create_json_from_api(graphql_url, "voters_data.json", graphql_query, variables, headers, True):
              json_to_csv("voters_data.json", output_data)
              temp =temp+ 10000
              print(temp)
            else:
              break
  
  print("data collection compltered for proposal - id:",proposal_id)          

      
