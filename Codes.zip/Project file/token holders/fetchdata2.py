import http.client
import json
import csv
import os
import ast
def convert_json_to_csv(json_data, csv_file_path):
    # Check if the CSV file exists
    csv_file_exists = os.path.exists(csv_file_path)
    
    # Write data to CSV
    with open(csv_file_path, 'a', newline='',encoding='utf-8') as csv_file:
        csv_writer = csv.DictWriter(csv_file, fieldnames=['Balance.Amount', 'Holder.Address'])
        if not csv_file_exists:
            csv_writer.writeheader()

        # Write data rows
        token_holders = json_data.get("data", {}).get("EVM", {}).get("TokenHolders", [])
        for row in token_holders:
            # Extract nested values
            balance_amount = row.get('Balance', {}).get('Amount')
            holder_address = row.get('Holder', {}).get('Address')
            
            # Convert Amount to float (assuming it represents a numerical value)
            
            csv_writer.writerow({'Balance.Amount': balance_amount, 'Holder.Address': holder_address})

    print(f"Data has been converted to CSV and saved to {csv_file_path}")



# Set your desired parameters
desired_date = "2024-3-17"
token_smart_contract = "0x912CE59144191C1204E64559FE8253a0e49E6548"
descending_field = "Balance_Amount"
limit_count = 20000
offset_value = 0
temp = 900000

# Make requests until reaching the desired total count

# query MyQuery {
#   EVM(dataset: archive, network: eth) {
#     TokenHolders(
#       date: "2023-10-20"
#       tokenSmartContract: "0x912CE59144191C1204E64559FE8253a0e49E6548"
#       where: {Balance: {Amount: {gt: "0"}}}
#     ) {
#       uniq(of: Holder_Address)
#     }
#   }
# }

while temp < 3000000:
    conn = http.client.HTTPSConnection("streaming.bitquery.io")
    payload = json.dumps({
    "query": "query MyQuery {\n  EVM(dataset: archive, network: arbitrum) {\n    TokenHolders(\n      date: \"2024-3-18\"\n      tokenSmartContract: \"0x912CE59144191C1204E64559FE8253a0e49E6548\"\n      limit: {count: " + str(limit_count) + ", offset: " + str(offset_value) + "}\n  ) {\n      uniq(of: Holder_Address)\n      Balance {\n        Amount\n      }\n      Holder {\n        Address\n      }\n    }\n  }\n}\n",
    "variables": "{}"
    })
    headers = {
    'Content-Type': 'application/json',
    'X-API-KEY': 'BQYfG5gkiJ4zzWFLiFeDjL5E6ntgQucN',
    'Authorization': 'Bearer ory_at_81pwkZwYFupABc40vgYlqHxPcOs5Wa97gCXFMyozbjs.9PwVWI8lzLCduekS8cRm5xquE6cTlOcjXf2nqCFgtDM'
    }
    conn.request("POST", "/graphql", payload, headers)
    res = conn.getresponse()
    data = res.read()
    data_str = data.decode("utf-8")
    # Load the string as JSON
    try:
    # Load the string as JSON
        json_data = json.loads(data_str)
        token_holders = json_data.get("data", {}).get("EVM", {}).get("TokenHolders", [])
        total_count = len(token_holders) if isinstance(token_holders, list) else 0
        print(f"Total count of entries in the data: {total_count}")

        # Convert JSON data to CSV
        csv_file_path = "data2.csv"
        convert_json_to_csv(json_data, csv_file_path)

        # Update offset for next request
        temp += limit_count
        offset_value = temp

    except json.JSONDecodeError as e:
        print("Error decoding JSON data:", e)
        print("Data received:", data_str)
    except Exception as e:
        print("An error occurred:", e)
