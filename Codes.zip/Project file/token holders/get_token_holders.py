import requests
from datetime import datetime
import json
from data_juggler import *
# GraphQL endpoint URL
graphql_url = 'https://api.tally.xyz/query'

graphql_query= """query Accounts(  

  $addresses: [Address!]
) {
  accounts(
    addresses: $addresses
  ) {
    id
    address
    ens
    twitter
    name
    participations{
      stats {
        createdProposalsCount 
        delegationCount
        voteCount
        # recentParticipationRate 
        tokenBalance 
      }
    }
    
  }
}
"""
headers = {
    "Api-key": "d38c4414051a92477770f9998aa9be4c2183ea815b6ace505ec5e29b856fc36b"
}
  
input_data="token_holders/voter_data.csv"
json_file="token_holders/token_holders_data.json"
with open(input_data, 'r', encoding='utf-8') as input_file:
    csv_reader = csv.reader(input_file)
    header = next(csv_reader)
    account_id_list = ["{}".format(row[1]) for _, row in zip(range(10), csv_reader)]

# Join the list elements with double-quoted strings and a comma
formatted_addresses = '[{}]'.format(', '.join(['"{}"'.format(address) for address in account_id_list]))

# Creating a dictionary with the desired format
variables = {
    "addresses": formatted_addresses
}


# variables["addresses"]=account_id_list
print(len(account_id_list))
# print(account_id_list)
print(variables["addresses"])


create_json_from_api(graphql_url,json_file,graphql_query,variables,headers,True)


