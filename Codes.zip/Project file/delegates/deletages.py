import requests
from datetime import datetime
import json
import pandas as pd
import json
import os 
import requests
import json
import csv 
import os


from data_juggler import create_json_from_api
# GraphQL endpoint URL
graphql_url = 'https://api.tally.xyz/query'

str=None
# print(str)
# input("")
def json_to_csv2(json_file, csv_file):
      
        with open(json_file, 'r') as file:
                response_data = json.load(file)
            
                data = response_data.get("data", {}).get("delegates", {}).get("nodes", [])
                df = pd.json_normalize(data)
                df.to_csv(csv_file, mode='a', header=False, index=False)
            
def check_csv_existence(file_path):
    return os.path.exists(file_path) and os.path.isfile(file_path) and file_path.endswith('.csv')
          
    print(f"Data appended to existing CSV file: {csv_file}")

def json_to_csv(json_file, csv_file):
  
        with open(json_file, 'r') as f:
          datas = json.load(f)
          data = datas.get("data", {}).get("delegates", {}).get("nodes", [])
                
        account_addresses = []
        used_powers = []
        delegated_powers = []
        votes_counts = []
        delegators_counts = []

        # Iterate through each entry in the JSON data
        for entry in data:
            total_used_power = 0
            total_delegated_power = 0
            current_power = 0
            delegators = entry.get('delegatorsCount', 0)
            account_address=entry.get("account","").get("address","")
            # Iterate through vote changes in the current entry
            for change in entry.get('voteChanges', []):
                # Calculate current voting power
                current_power = int(change.get('newBalance', 0))

                # Calculate total used and delegated voting power
                net_change = int(change.get('netChange', 0))
                if net_change > 0:
                    total_delegated_power += net_change
                else:
                    total_used_power -= net_change
              
            # Append data to lists
            account_addresses.append(account_address)
            used_powers.append(total_used_power)
            delegated_powers.append(total_delegated_power)
            votes_counts.append(current_power)
            delegators_counts.append(delegators)

        # Create DataFrame
        df = pd.DataFrame({
            'account.address': account_addresses,
            'used_power': used_powers,
            'delegated_power': delegated_powers,
            'votesCount': votes_counts,
            'delegatorsCount': delegators_counts
        })

        # Check if the CSV file exists
        if check_csv_existence(csv_file):
            # If the CSV file exists, append data without the header
            df.to_csv(csv_file, mode='a', header=False, index=False)
            print(f"Data appended to existing CSV file: {csv_file}")
        else:
            # If the CSV file does not exist, write the header
            df.to_csv(csv_file, header=True, index=False)
            print(f"CSV file successfully created: {csv_file}")
  
graphql_query= """query FetchDelegatesWithFilters($input: DelegatesInput!) {
    delegates(input: $input) {
      nodes {
        ... on Delegate {
          votesCount
          delegatorsCount
          account {
            address
          }
          voteChanges {
            prevBalance
      	newBalance
      			netChange
          }
          
        }
        
      }
      pageInfo {
        firstCursor
        lastCursor
        count
      }
    }
  }

"""
variable={
      "input": {
          "filters": {
          "governorId": "eip155:42161:0x789fC99093B09aD01C34DC7251D0C89ce743e5a4",
          "organizationId": "2206072050315953936"
          },
      "sort": {
          "isDescending": True,

          "sortBy": "VOTES"
      },
      "page": {
          "afterCursor": "1010000000000000000;2216915656874395056",
          "limit": 20
      }
      }

}
cnt=0
csv_file="voting.csv"

while True:
    

      headers = {
          "Api-key": "d38c4414051a92477770f9998aa9be4c2183ea815b6ace505ec5e29b856fc36b"
      }

      json_file="delegates.json"

      str=create_json_from_api(graphql_url,json_file,graphql_query,variable,headers,True)
      variable["input"]["page"]["afterCursor"]=str
      print(variable["input"]["page"]["afterCursor"])

      # print(type(variable["input"]["page"]["afterCursor"]))
      # last_cursor_start = str.find("lastCursor": ") + len("lastCursor": ")
      # last_cursor_end = str.find(", last_cursor_start)

      # Extract the substring containing the value of 'lastCursor'
      # last_cursor_value = str[last_cursor_start:last_cursor_end]
      # print(variable["input"]["page"]["afterCursor"])
      json_to_csv(json_file,csv_file)
      
      cnt+=20
      
    
print(str)

